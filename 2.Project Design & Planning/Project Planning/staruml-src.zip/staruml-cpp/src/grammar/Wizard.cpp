///////////////////////////////////////////////////////////
//  Wizard.cpp
//  Implementation of the Class Wizard
//  Created on:      08-6-2004 ���� 10:38:12
///////////////////////////////////////////////////////////

#include "Wizard.h"


Wizard::Wizard(){

}


Wizard::Wizard(CWnd* pParent){

}


/**
 * standard constructor
 */
Wizard::~Wizard(){

}


void Wizard::SetPrefs(CPreferences* in_prefs){

}


void Wizard::Localize(){

}


BOOL Wizard::OnInitDialog(){

}


void Wizard::DoDataExchange(CDataExchange* pDX){

}


void Wizard::OnBnClickedApply(){

}


void Wizard::OnBnClickedCancel(){

}


void Wizard::OnBnClickedWizRadioOsNtxp(){

}


void Wizard::OnBnClickedWizRadioUs98me(){

}


void Wizard::OnBnClickedWizLowdownloadRadio(){

}


void Wizard::OnBnClickedWizMediumdownloadRadio(){

}


void Wizard::OnBnClickedWizHighdownloadRadio(){

}


void Wizard::OnBnClickedWizResetButton(){

}


void Wizard::SetCustomItemsActivation(){

}


void Wizard::OnNMClickProviders(NMHDR* pNMHDR, LRESULT* pResult){

}



