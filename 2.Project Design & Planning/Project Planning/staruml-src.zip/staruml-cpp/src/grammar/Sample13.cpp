namespace A {

namespace B {
enum testEnum {a, b=3, c};
}
}
class C {
	public:
	friend test();
	template <class T, int i> class D { };
	virtual int test2(int param1, int param2) const = 0	// :{
	;
};

void C::test() {

int dadsa
= 100
;
dadasdsad ==dsa====

};


