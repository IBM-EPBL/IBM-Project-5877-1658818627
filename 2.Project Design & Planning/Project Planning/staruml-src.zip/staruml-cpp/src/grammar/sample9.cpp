void main(6
{
}
