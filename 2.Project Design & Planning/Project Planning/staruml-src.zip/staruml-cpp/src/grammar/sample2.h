class Wizard : public CDialog
{
	DECLARE_DYNAMIC(Wizard)
	void DECLARE_DYNAMIC(Wizard);
};
